    <?php

    class conexionDB {
        private $servidor;
        private $usuario;
        private $contrasena;
        private $basededatos;
        private $conexion;

        public function __construct() {
            $this->servidor = "localhost";
            $this->usuario = "apex";
            $this->contrasena = "apex";
            $this->basededatos = "apex";

            $this->conexion = mysqli_connect(
                $this->servidor,
                $this->usuario,
                $this->contrasena,
                $this->basededatos
            );

            if (!$this->conexion) {
                die("Error en la conexión: " . mysqli_connect_error());
            }
        }

        public function buscar($tabla, $datos) {
            $peticion = "SELECT * FROM " . $tabla . " WHERE ";
            foreach ($datos as $clave => $valor) {
                $peticion .= $clave . "='" . mysqli_real_escape_string($this->conexion, $valor) . "' AND ";
            }
            $peticion = rtrim($peticion, ' AND ');

            $resultado = mysqli_query($this->conexion, $peticion);
            $retorno = [];

            if ($resultado) {
                while ($fila = mysqli_fetch_assoc($resultado)) {
                    $retorno[] = $fila;
                }
            } else {
                return json_encode(["error" => mysqli_error($this->conexion)]);
            }

            if (empty($retorno)) {
                return json_encode(["success" => false, "message" => "Usuario no encontrado"]);
            }

            return json_encode(["success" => true, "data" => $retorno], JSON_PRETTY_PRINT);
        }

        public function buscarSimilar($tabla, $datos) {
            $peticion = "SELECT * FROM " . $tabla . " WHERE ";
            foreach ($datos as $clave => $valor) {
                $peticion .= $clave . " LIKE '%". mysqli_real_escape_string($this->conexion, $valor) . "%' AND ";
            }
            $peticion = rtrim($peticion, ' AND ');

            $resultado = mysqli_query($this->conexion, $peticion);
            $retorno = [];

            if ($resultado) {
                while ($fila = mysqli_fetch_assoc($resultado)) {
                    $retorno[] = $fila;
                }
            } else {
                return json_encode(["error" => mysqli_error($this->conexion)]);
            }

            if (empty($retorno)) {
                return json_encode(["success" => false, "message" => "Usuario no encontrado"]);
            }

            return json_encode(["success" => true, "data" => $retorno], JSON_PRETTY_PRINT);
        }

        public function seleccionaTabla($tabla) {
            $query = "SELECT * FROM ".$tabla.";";
            $result = mysqli_query($this->conexion , $query);
            $resultado = [];

            while ($row = mysqli_fetch_assoc($result)) {
                $resultado[] = $row;
            }

            $json = json_encode($resultado, JSON_PRETTY_PRINT);
            return $json;
        }

        public function listadoTablas() {
            $query = "
                SELECT
                    table_name AS 'Tables_in_".$this->basededatos."',
                    table_comment AS 'Comentario'
                FROM
                    information_schema.tables
                WHERE
                    table_schema = '".$this->basededatos."';
            ";

            $result = mysqli_query($this->conexion , $query);
            $resultado = [];

            while ($row = mysqli_fetch_assoc($result)) {
                $resultado[] = $row;
            }

            $json = json_encode($resultado, JSON_PRETTY_PRINT);
            return $json;
        }

        public function columnasTabla($tabla) {
            $query = "SHOW COLUMNS FROM ".$tabla.";";
            $result = mysqli_query($this->conexion , $query);
            $resultado = [];

            while ($row = mysqli_fetch_assoc($result)) {
                $resultado[] = $row;
            }

            $json = json_encode($resultado, JSON_PRETTY_PRINT);
            return $json;
        }

        public function insertaTabla($tabla, $valores) {
            $campos = "";
            $datos = "";

            foreach ($valores as $clave => $valor) {
                $campos .= $clave . ",";
                $datos .= "'" . mysqli_real_escape_string($this->conexion, $valor) . "',";
            }

            $campos = rtrim($campos, ",");
            $datos = rtrim($datos, ",");

            $query = "INSERT INTO ".$tabla." (".$campos.") VALUES (".$datos.");";
            $result = mysqli_query($this->conexion , $query);

            if (!$result) {
                return json_encode(["success" => false, "error" => mysqli_error($this->conexion)]);
            }

            return json_encode(["success" => true]);
        }

        public function actualizaTabla() {
    $data = json_decode(file_get_contents("php://input"), true);

    // Validación de entrada
    if (!isset($data['tabla'], $data['clavePrimaria'], $data['campo'], $data['valor'])) {
        echo json_encode(["success" => false, "error" => "Faltan datos en la solicitud."]);
        return;
    }

    $tabla = $data['tabla'];
    $clavePrimaria = $data['clavePrimaria'];
    $campo = $data['campo'];
    $valor = $data['valor'];

    // Construir consulta SQL preparada
    $query = "UPDATE $tabla SET $campo = ? WHERE Identificador = ?";
    $stmt = $this->conexion->prepare($query);

    if (!$stmt) {
        echo json_encode(["success" => false, "error" => $this->conexion->error]);
        return;
    }

    // Asignar parámetros y ejecutar
    $stmt->bind_param("si", $valor, $clavePrimaria);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "error" => $stmt->error]);
    }

    $stmt->close();
}



        public function eliminaTabla($tabla, $id) {
               $query = "DELETE FROM ".$tabla." WHERE Identificador = ".(int)$id.";";
            $result = mysqli_query($this->conexion , $query);

            if (!$result) {
                return json_encode(["success" => false, "error" => mysqli_error($this->conexion)]);
            }

            return json_encode(["success" => true]);
        }
    }
    ?>
