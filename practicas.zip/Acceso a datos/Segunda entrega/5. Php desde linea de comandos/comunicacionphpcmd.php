<?php

	echo "Hola mundo desde la linea de comandos \n";
?>
